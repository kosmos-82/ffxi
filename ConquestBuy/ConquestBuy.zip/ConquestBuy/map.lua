return {
	-- CP Items
	[16776] = {Name="scythe",  Cost=4000, Option=32800, Index=0},
	[16712] = {Name="axe",     Cost=4000, Option=32800, Index=0},
	[16712] = {Name="Gun",     Cost=4000, Option=32800, Index=0},
  --  [17253] = {Name="Gun",     Cost=16000, Option=32837, Index=0},
	[16844] = {Name="Halberd", Cost=4000, Option=32800, Index=0},
}
